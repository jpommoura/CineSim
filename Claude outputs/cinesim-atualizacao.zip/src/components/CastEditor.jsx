import { castTotal, normalizeRole, resizeImage, ROLES, uid } from '../utils.js'
import { tmdbEnabled } from '../tmdb.js'
import { useI18n } from '../i18n.jsx'
import ActorSearch from './ActorSearch.jsx'

export default function CastEditor({ film, onChange }) {
  const { t, money } = useI18n()
  const setChars = (fn) => onChange((f) => ({ ...f, characters: fn(f.characters) }))
  const setActors = (fn) => onChange((f) => ({ ...f, actors: fn(f.actors) }))

  const addCharacter = () =>
    setChars((cs) => [...cs, { id: uid(), name: '', role: 'main', description: '', photo: null }])
  const updateChar = (id, patch) => setChars((cs) => cs.map((c) => (c.id === id ? { ...c, ...patch } : c)))
  const removeChar = (id) =>
    onChange((f) => ({
      ...f,
      characters: f.characters.filter((c) => c.id !== id),
      actors: f.actors.map((a) => (a.characterId === id ? { ...a, characterId: null } : a)),
      acts: f.acts.map((act) => ({
        ...act,
        scenes: act.scenes.map((s) => ({ ...s, characterIds: s.characterIds.filter((x) => x !== id) })),
      })),
    }))

  const onPhoto = async (id, file) => {
    if (!file) return
    try {
      updateChar(id, { photo: await resizeImage(file) })
    } catch {
      alert(t('photo_error'))
    }
  }

  const addActor = () =>
    setActors((as) => [...as, { id: uid(), name: '', fee: 0, characterId: null, tmdbId: null, photo: null, knownFor: [] }])
  const updateActor = (id, patch) => setActors((as) => as.map((a) => (a.id === id ? { ...a, ...patch } : a)))
  const removeActor = (id) => setActors((as) => as.filter((a) => a.id !== id))

  const actorOf = (charId) => film.actors.find((a) => a.characterId === charId)
  const total = castTotal(film)
  const hasBudget = film.budget !== null
  const over = hasBudget && total > film.budget

  return (
    <div className="stack">
      {hasBudget && (
        <div className={`card budget-strip ${over ? 'over' : ''}`}>
          <span>{t('cast_fees', { total: money(total), budget: money(film.budget) })}</span>
          <span>{over ? t('cast_over', { v: money(total - film.budget) }) : t('cast_left', { v: money(film.budget - total) })}</span>
        </div>
      )}

      <div className="section-head">
        <h2>{t('characters')}</h2>
        <button className="btn primary" onClick={addCharacter}>{t('character_add')}</button>
      </div>

      {film.characters.length === 0 && <p className="muted">{t('characters_empty')}</p>}

      <div className="char-grid">
        {film.characters.map((c) => {
          const actor = actorOf(c.id)
          return (
            <div key={c.id} className="card char-card">
              <label className="photo">
                {c.photo ? <img src={c.photo} alt={c.name} /> : <span>{t('photo_add')}<br /><small>{t('photo_opt')}</small></span>}
                <input type="file" accept="image/*" hidden onChange={(e) => onPhoto(c.id, e.target.files[0])} />
              </label>
              {c.photo && <button className="link small" onClick={() => updateChar(c.id, { photo: null })}>{t('photo_remove')}</button>}
              <input value={c.name} onChange={(e) => updateChar(c.id, { name: e.target.value })} placeholder={t('character_name_ph')} />
              <select value={normalizeRole(c.role)} onChange={(e) => updateChar(c.id, { role: e.target.value })}>
                {ROLES.map((r) => <option key={r} value={r}>{t(`role_${r}`)}</option>)}
              </select>
              <textarea rows={3} value={c.description} onChange={(e) => updateChar(c.id, { description: e.target.value })} placeholder={t('character_desc_ph')} />
              <div className="muted small">
                {actor ? <>🎭 {t('played_by')} <strong>{actor.name || t('actor_unnamed')}</strong></> : t('no_actor')}
              </div>
              <button className="btn danger-ghost small" onClick={() => removeChar(c.id)}>{t('delete')}</button>
            </div>
          )
        })}
      </div>

      <div className="section-head">
        <h2>{t('actors')}</h2>
        <button className="btn primary" onClick={addActor}>{t('actor_add')}</button>
      </div>

      {!tmdbEnabled && <p className="muted small">💡 {t('tmdb_hint')}</p>}

      {film.actors.length === 0 ? (
        <p className="muted">{t('actors_empty')}</p>
      ) : (
        <div className="card table-wrap">
          <table>
            <thead>
              <tr><th>{t('col_actor')}</th><th>{t('col_character')}</th><th>{t('col_fee')}</th><th></th></tr>
            </thead>
            <tbody>
              {film.actors.map((a) => (
                <tr key={a.id}>
                  <td>
                    <ActorSearch
                      actor={a}
                      onType={(name) => updateActor(a.id, { name, tmdbId: null, photo: null, knownFor: [] })}
                      onPick={(p) => updateActor(a.id, p)}
                    />
                  </td>
                  <td>
                    <select value={a.characterId || ''} onChange={(e) => updateActor(a.id, { characterId: e.target.value || null })}>
                      <option value="">{t('none_option')}</option>
                      {film.characters.map((c) => {
                        const taken = film.actors.some((x) => x.id !== a.id && x.characterId === c.id)
                        return (
                          <option key={c.id} value={c.id} disabled={taken}>
                            {(c.name || t('unnamed')) + (taken ? t('already_cast') : '')}
                          </option>
                        )
                      })}
                    </select>
                  </td>
                  <td>
                    <input type="number" min="0" step="100" value={a.fee} onChange={(e) => updateActor(a.id, { fee: Math.max(0, Number(e.target.value)) })} />
                  </td>
                  <td><button className="icon danger" onClick={() => removeActor(a.id)} title={t('remove')}>×</button></td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr><td colSpan={2}>{t('cast_total')}</td><td colSpan={2}><strong>{money(total)}</strong></td></tr>
            </tfoot>
          </table>
        </div>
      )}
    </div>
  )
}
